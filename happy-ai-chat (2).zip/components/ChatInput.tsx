import React, { useState, useRef, ChangeEvent, KeyboardEvent } from 'react';
import { SendIcon, PaperclipIcon } from './icons';
import { AVAILABLE_CHAT_MODELS, IMAGE_GEN_COMMAND, CODE_GEN_COMMAND } from '../constants';
import { UploadedFile } from '../types';
import ToggleSwitch from './ToggleSwitch';

interface ChatInputProps {
  onSendMessage: (prompt: string, file?: UploadedFile) => void;
  isLoading: boolean;
  model: string;
  setModel: (model: string) => void;
  useGoogleSearch: boolean;
  setUseGoogleSearch: (use: boolean) => void;
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage, isLoading, model, setModel, useGoogleSearch, setUseGoogleSearch }) => {
  const [prompt, setPrompt] = useState('');
  const [file, setFile] = useState<UploadedFile | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
        if (selectedFile.size > 500 * 1024 * 1024) { // 1GB limit
            alert("File size should not exceed 1GB. Please be aware that very large files may fail to upload due to browser or API limitations.");
            return;
        }
        const reader = new FileReader();
        reader.onloadend = () => {
            setFile({
                name: selectedFile.name,
                type: selectedFile.type,
                base64: reader.result as string,
            });
        };
        reader.readAsDataURL(selectedFile);
    }
  };
  
  const handleSend = () => {
    if ((prompt.trim() || file) && !isLoading) {
      onSendMessage(prompt.trim(), file || undefined);
      setPrompt('');
      setFile(null);
      if(fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  
  const isImageGen = prompt.startsWith(IMAGE_GEN_COMMAND);
  const isCodeGen = prompt.startsWith(CODE_GEN_COMMAND);
  const isCommand = isImageGen || isCodeGen;
  
  const getPlaceholder = () => {
    if (isImageGen) return `e.g. A photo of a cat on a skateboard`;
    if (isCodeGen) return `e.g. A python function to sort a list of numbers`;
    return "Chat with Happy AI...";
  };

  return (
    <div className="bg-transparent p-4 border-t border-white/20 dark:border-white/10">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white/30 dark:bg-black/20 backdrop-blur-lg rounded-xl flex flex-col transition-shadow duration-200 focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-offset-transparent focus-within:ring-[--theme-color] border border-white/10">
          <div className="flex items-center">
            <textarea
              className="flex-1 p-2 bg-transparent focus:outline-none resize-none text-black dark:text-white placeholder-gray-500 dark:placeholder-gray-400"
              placeholder={getPlaceholder()}
              rows={1}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={isLoading}
              aria-label="Chat input"
            />
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              accept="image/*,video/mp4,audio/mpeg,application/pdf,.doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.blend,.obj,.fbx,.mtl,.gltf"
              disabled={isLoading || isCommand}
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className={`p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-black/10 dark:hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed`}
              disabled={isLoading || isCommand}
              title={isCommand ? "File upload disabled for this command" : "Attach file"}
              aria-label="Attach file"
            >
              <PaperclipIcon className="w-6 h-6" />
            </button>
            <button
              onClick={handleSend}
              disabled={isLoading || (!prompt.trim() && !file)}
              className="p-2 rounded-full bg-[--theme-color] text-white hover:opacity-90 disabled:bg-gray-400 dark:disabled:bg-gray-500 disabled:cursor-not-allowed transition-colors ml-2"
              aria-label="Send message"
            >
              <SendIcon className="w-6 h-6" />
            </button>
          </div>
          {file && (
            <div className="p-2 mt-2 border-t border-gray-200/50 dark:border-gray-600/50">
              <div className="bg-black/10 dark:bg-white/10 text-sm text-gray-700 dark:text-gray-300 px-3 py-1 rounded-full inline-flex items-center">
                <span>{file.name}</span>
                <button onClick={() => setFile(null)} className="ml-2 font-bold text-gray-500 dark:text-gray-400 hover:text-black dark:hover:text-white">&times;</button>
              </div>
            </div>
          )}
        </div>
        <div className="flex justify-between items-center mt-2 text-xs text-gray-500 dark:text-gray-400 px-2">
            <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">Model:</span>
                    <select
                        value={model}
                        onChange={(e) => setModel(e.target.value)}
                        className="bg-black/10 dark:bg-white/10 border border-gray-300/30 dark:border-gray-500/30 rounded-md px-2 py-1 focus:outline-none focus:ring-1 focus:ring-black dark:focus:ring-white text-sm"
                        disabled={isLoading || isCommand}
                        aria-label="Select AI model"
                    >
                        {AVAILABLE_CHAT_MODELS.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                    </select>
                </div>
                <ToggleSwitch 
                  id="deep-search-toggle"
                  label="Deep Search"
                  checked={useGoogleSearch}
                  onChange={setUseGoogleSearch}
                  disabled={isLoading || isCommand}
                />
            </div>
            <p>Use {IMAGE_GEN_COMMAND} or {CODE_GEN_COMMAND} [prompt].</p>
        </div>
      </div>
    </div>
  );
};

export default ChatInput;