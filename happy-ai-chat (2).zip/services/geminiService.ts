import { GoogleGenAI, GenerateContentResponse, Part, Content } from "@google/genai";
import { Message, Role, UploadedFile, GroundingSource, ChatSession } from '../types';
import { IMAGE_GENERATION_MODEL } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const buildHistory = (messages: Message[]): Content[] => {
  return messages.map((msg) => {
    // Filter out code generation messages from history
    if (msg.isCode) {
        return { role: msg.role, parts: [] };
    }
      
    const parts: Part[] = [];

    // For multi-modal prompts, the file part should come first.
    if (msg.fileData) {
      const mimeTypeMatch = msg.fileData.match(/^data:(.*?);base64,/);
      if (mimeTypeMatch) {
        parts.push({
          inlineData: {
            mimeType: mimeTypeMatch[1],
            data: msg.fileData.replace(/^data:(.*?);base64,/, ''),
          },
        });
      }
    }
    
    // Only add a text part if there's text.
    if (msg.text) {
        parts.push({ text: msg.text });
    }

    return { role: msg.role, parts };
  }).filter(c => c.parts.length > 0);
};


export const streamChat = async (
  messages: Message[],
  model: string,
  useGoogleSearch: boolean,
  chatHistory?: ChatSession[]
) => {
  const contents = buildHistory(messages);
  
  const baseSystemInstruction = "You are Happy, a friendly and empathetic AI assistant. Your goal is to be both logical and informative while also being understanding and personable. Listen carefully to the user, offer helpful and well-reasoned responses, and maintain a supportive and positive tone throughout the conversation. Be a useful and kind companion.";
  let systemInstruction = baseSystemInstruction;

  if (chatHistory && chatHistory.length > 0) {
      const historyContext = chatHistory
          .map(session => {
              const relevantMessages = session.messages.slice(0, 4);
              const messageSummary = relevantMessages
                  .map(msg => {
                      const prefix = msg.role === Role.USER ? 'User' : 'Happy';
                      const text = msg.text.length > 150 ? `${msg.text.substring(0, 150)}...` : msg.text;
                      return `${prefix}: ${text}`;
                  })
                  .join('\n');
              
              return `Chat titled "${session.title}":\n${messageSummary}`;
          })
          .join('\n\n---\n\n');

      systemInstruction = `${baseSystemInstruction}\n\nYou have a memory of past conversations. The user might ask you about things you've discussed before. Use the following summary of past chats to inform your response if relevant. Do not mention that you are reviewing past data unless the user explicitly asks how you remember things.\n\n=== SUMMARY OF PAST CONVERSATIONS ===\n${historyContext}\n=== END SUMMARY ===`;
  }

  const config = {
      tools: useGoogleSearch ? [{ googleSearch: {} }] : [],
      systemInstruction,
  };

  const stream = await ai.models.generateContentStream({
    model,
    contents,
    config,
  });

  return stream;
};

export const generateCode = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                systemInstruction: "You are a code generation expert. Respond ONLY with the raw code for the user's request, enclosed in a single markdown block (e.g., ```language\\n...\\n```). Do not add any explanation, introduction, or conclusion. If you cannot determine the language, use ```. If the request is not for code, respond with ```\nI can only generate code. Please ask me to write some code.\n```",
                thinkingConfig: { thinkingBudget: 0 },
            }
        });
        return response.text.trim();
    } catch (error) {
        console.error('Error generating code:', error);
        return '```\nError: Could not generate code.\n```';
    }
};

export const generateImage = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateImages({
            model: IMAGE_GENERATION_MODEL,
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/png',
                aspectRatio: '1:1',
            },
        });

        if (response.generatedImages && response.generatedImages.length > 0) {
            const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
            return `data:image/png;base64,${base64ImageBytes}`;
        }
        throw new Error('No image was generated.');
    } catch (error) {
        console.error('Error generating image:', error);
        return 'Error: Could not generate image.';
    }
};

export const getGroundingSources = (response: GenerateContentResponse): GroundingSource[] => {
    try {
        const metadata = response.candidates?.[0]?.groundingMetadata;
        if (metadata?.groundingChunks) {
            return metadata.groundingChunks
                .map(chunk => chunk.web)
                .filter((web): web is { uri: string; title: string } => !!web && !!web.uri)
                .map(web => ({ uri: web.uri, title: web.title || web.uri }));
        }
    } catch (e) {
        console.error("Error parsing grounding sources:", e);
    }
    return [];
};

export const generateChatTitle = async (prompt: string): Promise<string> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Generate a very short, concise title (4 words max) for a chat that starts with this user prompt: "${prompt}"`,
            config: {
                // Prevent long thinking for a simple task
                thinkingConfig: { thinkingBudget: 0 },
                maxOutputTokens: 20,
            }
        });
        // Clean up the title, remove quotes if any
        return response.text.trim().replace(/["']/g, '');
    } catch (error) {
        console.error('Error generating title:', error);
        return 'New Chat'; // Fallback title
    }
};