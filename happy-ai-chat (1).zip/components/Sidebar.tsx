import React from 'react';
import { ChatSession } from '../types';
import { THEME_COLORS } from '../constants';
import { CloseIcon, TrashIcon, SunIcon, MoonIcon } from './icons';
import ToggleSwitch from './ToggleSwitch';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  chatSessions: ChatSession[];
  currentSessionId: string | null;
  onSelectChat: (sessionId: string) => void;
  onDeleteChat: (sessionId: string) => void;
  onNewChat: () => void;
  themeColor: string;
  setThemeColor: (color: string) => void;
  colorMode: 'light' | 'dark';
  setColorMode: (mode: 'light' | 'dark') => void;
  useMemory: boolean;
  setUseMemory: (use: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  onClose,
  chatSessions,
  currentSessionId,
  onSelectChat,
  onDeleteChat,
  onNewChat,
  themeColor,
  setThemeColor,
  colorMode,
  setColorMode,
  useMemory,
  setUseMemory,
}) => {
  return (
    <>
      <div 
        className={`fixed inset-0 bg-black/20 backdrop-blur-sm z-30 transition-opacity ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
        aria-hidden="true"
      ></div>
      <aside
        className={`fixed top-0 right-0 h-full w-80 bg-white/70 dark:bg-gray-900/70 backdrop-blur-xl text-gray-800 dark:text-gray-200 shadow-lg transform transition-transform z-40 flex flex-col ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
        role="dialog"
        aria-modal="true"
        aria-labelledby="sidebar-title"
      >
        <div className="p-4 flex justify-between items-center border-b border-white/20 dark:border-white/10 flex-shrink-0">
          <h2 id="sidebar-title" className="text-lg font-semibold">History & Settings</h2>
          <button onClick={onClose} className="p-1 rounded-full hover:bg-black/10 dark:hover:bg-white/10" aria-label="Close menu">
            <CloseIcon className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <button
            onClick={() => { onNewChat(); onClose(); }}
            className="w-full text-left px-4 py-2 rounded-lg bg-black/5 dark:bg-white/5 hover:bg-black/10 dark:hover:bg-white/10 transition-colors mb-4 font-medium"
          >
            + New Chat
          </button>
          <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2">Recent Chats</h3>
          <ul className="space-y-2">
            {chatSessions.map(session => (
              <li 
                key={session.id} 
                className={`flex items-center group transition-all duration-300 ease-in-out ${
                    session.isNew ? 'opacity-0 transform -translate-x-4' : 'opacity-100 translate-x-0'
                } ${
                    session.isDeleting ? 'opacity-0' : ''
                }`}
              >
                <button
                  onClick={() => { onSelectChat(session.id); onClose(); }}
                  className={`flex-1 text-left text-sm truncate px-3 py-2 rounded-l-md transition-colors ${
                    session.id === currentSessionId ? 'bg-[--theme-color] text-white' : 'hover:bg-black/5 dark:hover:bg-white/5'
                  }`}
                >
                  {session.title}
                </button>
                <button
                  onClick={() => onDeleteChat(session.id)}
                  className="p-2 text-current opacity-60 group-hover:opacity-100 hover:text-red-500 bg-transparent hover:bg-red-500/10 rounded-r-md transition-all"
                  title="Delete chat"
                >
                    <TrashIcon className="w-4 h-4" />
                </button>
              </li>
            ))}
             {chatSessions.length === 0 && <p className="text-sm text-gray-500 dark:text-gray-400">No past chats.</p>}
          </ul>
        </div>
        
        <div className="flex-shrink-0 p-4 border-t border-white/20 dark:border-white/10 space-y-4">
             <div>
                <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">Memory</h3>
                <ToggleSwitch
                    id="memory-toggle"
                    label="Enable Memory"
                    checked={useMemory}
                    onChange={setUseMemory}
                />
             </div>
             <div>
                <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">Appearance</h3>
                <div className="p-1 bg-black/5 dark:bg-white/5 rounded-lg flex">
                    <button onClick={() => setColorMode('light')} className={`w-1/2 py-1.5 rounded-md text-sm font-medium flex items-center justify-center gap-2 transition-colors ${colorMode === 'light' ? 'bg-white/80 shadow-sm text-gray-800' : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}`}>
                        <SunIcon className="w-4 h-4"/>
                        Light
                    </button>
                    <button onClick={() => setColorMode('dark')} className={`w-1/2 py-1.5 rounded-md text-sm font-medium flex items-center justify-center gap-2 transition-colors ${colorMode === 'dark' ? 'bg-black/30 shadow-sm text-white' : 'text-gray-500 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200'}`}>
                        <MoonIcon className="w-4 h-4"/>
                        Dark
                    </button>
                </div>
             </div>
             <div>
                <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-3">Theme Color</h3>
                <div className="grid grid-cols-5 gap-2">
                    {THEME_COLORS.map(theme => (
                        <button
                            key={theme.name}
                            onClick={() => setThemeColor(theme.primary)}
                            className={`w-full h-8 rounded-lg focus:outline-none transition-transform duration-200 ease-in-out hover:scale-110 flex items-center justify-center text-white font-semibold text-sm shadow-md ${
                                themeColor === theme.primary ? 'ring-2 ring-offset-2 ring-offset-white dark:ring-offset-gray-900 ring-white' : ''
                            }`}
                            style={{ background: theme.gradient }}
                            title={theme.name}
                            aria-label={`Set theme to ${theme.name}`}
                        >
                        </button>
                    ))}
                </div>
             </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;