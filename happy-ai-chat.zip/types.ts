export enum Role {
  USER = 'user',
  MODEL = 'model',
}

export interface GroundingSource {
  uri: string;
  title: string;
}

export interface Message {
  id: string;
  role: Role;
  text: string;
  fileData?: string; // base64 data URL for any file
  fileName?: string;
  fileType?: string;
  sources?: GroundingSource[];
  isCode?: boolean;
}

export interface UploadedFile {
    name: string;
    type: string;
    base64: string;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  isNew?: boolean;
  isDeleting?: boolean;
}