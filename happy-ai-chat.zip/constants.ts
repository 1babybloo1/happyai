export const AVAILABLE_CHAT_MODELS = [
    { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash' },
    { id: 'gemini-1.5-pro', name: 'Gemini 1.5 Pro' },
    { id: 'gemini-1.5-flash', name: 'Gemini 1.5 Flash' },
];

export const IMAGE_GENERATION_MODEL = 'imagen-3.0-generate-002';
export const IMAGE_GEN_COMMAND = '/imagine';
export const CODE_GEN_COMMAND = '/code';

export const THEME_COLORS = [
    { name: 'Default', primary: '#1f2937', gradient: 'linear-gradient(to right, #374151, #1f2937)' },
    { name: 'Rose', primary: '#e11d48', gradient: 'linear-gradient(to right, #f43f5e, #be123c)' },
    { name: 'Blue', primary: '#2563eb', gradient: 'linear-gradient(to right, #3b82f6, #1d4ed8)' },
    { name: 'Green', primary: '#16a34a', gradient: 'linear-gradient(to right, #22c55e, #15803d)' },
    { name: 'Purple', primary: '#9333ea', gradient: 'linear-gradient(to right, #a855f7, #7e22ce)' },
    { name: 'Orange', primary: '#f97316', gradient: 'linear-gradient(to right, #fb923c, #ea580c)' },
    { name: 'Amber', primary: '#f59e0b', gradient: 'linear-gradient(to right, #fcd34d, #d97706)' },
    { name: 'Lime', primary: '#84cc16', gradient: 'linear-gradient(to right, #a3e635, #65a30d)' },
    { name: 'Emerald', primary: '#10b981', gradient: 'linear-gradient(to right, #34d399, #059669)' },
    { name: 'Teal', primary: '#14b8a6', gradient: 'linear-gradient(to right, #2dd4bf, #0d9488)' },
    { name: 'Cyan', primary: '#06b6d4', gradient: 'linear-gradient(to right, #22d3ee, #0891b2)' },
    { name: 'Sky', primary: '#0ea5e9', gradient: 'linear-gradient(to right, #38bdf8, #0284c7)' },
    { name: 'Indigo', primary: '#6366f1', gradient: 'linear-gradient(to right, #818cf8, #4f46e5)' },
    { name: 'Fuchsia', primary: '#d946ef', gradient: 'linear-gradient(to right, #e879f9, #c026d3)' },
    { name: 'Pink', primary: '#ec4899', gradient: 'linear-gradient(to right, #f472b6, #db2777)' },
];