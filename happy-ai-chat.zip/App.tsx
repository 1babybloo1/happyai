import React, { useState, useCallback, useEffect } from 'react';
import { Message, Role, UploadedFile, ChatSession } from './types';
import { streamChat, generateImage, generateCode, getGroundingSources, generateChatTitle } from './services/geminiService';
import { AVAILABLE_CHAT_MODELS, IMAGE_GEN_COMMAND, CODE_GEN_COMMAND, THEME_COLORS } from './constants';
import Header from './components/Header';
import ChatWindow from './components/ChatWindow';
import ChatInput from './components/ChatInput';
import Sidebar from './components/Sidebar';

const App: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [currentModel, setCurrentModel] = useState<string>(AVAILABLE_CHAT_MODELS[0].id);
    const [useGoogleSearch, setUseGoogleSearch] = useState<boolean>(false);
    const [isSwitchingChats, setIsSwitchingChats] = useState(false);
    const [isSidebarOpen, setIsSidebarOpen] = useState(false);
    
    // Chat History State
    const [chatSessions, setChatSessions] = useState<ChatSession[]>([]);
    const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);

    // Settings State
    const [themeColor, setThemeColor] = useState<string>(THEME_COLORS[0].primary);
    const [colorMode, setColorMode] = useState<'light' | 'dark'>('light');
    const [useMemory, setUseMemory] = useState<boolean>(true);


    // Load from localStorage on initial render
    useEffect(() => {
        try {
            const savedSessions = localStorage.getItem('happy-ai-chat-sessions');
            const savedTheme = localStorage.getItem('happy-ai-theme-color');
            const savedSessionId = localStorage.getItem('happy-ai-current-session-id');
            const savedColorMode = localStorage.getItem('happy-ai-color-mode');
            const savedUseMemory = localStorage.getItem('happy-ai-use-memory');

            if (savedColorMode === 'dark' || savedColorMode === 'light') {
                setColorMode(savedColorMode);
            } else if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
                setColorMode('dark');
            }
            
            if (savedUseMemory) {
                setUseMemory(JSON.parse(savedUseMemory));
            }

            if (savedSessions) {
                const sessions: ChatSession[] = JSON.parse(savedSessions);
                setChatSessions(sessions);
                
                if(savedSessionId && sessions.some(s => s.id === savedSessionId)) {
                    setCurrentSessionId(savedSessionId);
                    const currentSession = sessions.find(s => s.id === savedSessionId);
                    if (currentSession) {
                        setMessages(currentSession.messages);
                    }
                } else if (sessions.length > 0) {
                     const lastSession = sessions.sort((a,b) => b.createdAt - a.createdAt)[0];
                     setCurrentSessionId(lastSession.id);
                     setMessages(lastSession.messages);
                }
            }
            if (savedTheme) {
                 setThemeColor(savedTheme);
            }
        } catch (e) {
            console.error("Failed to load from localStorage", e);
        }
    }, []);

    // Save to localStorage whenever state changes
    useEffect(() => {
        try {
            // Filter out animation flags before saving
            const sessionsToSave = chatSessions.map(({ isNew, isDeleting, ...rest }) => rest);
            localStorage.setItem('happy-ai-chat-sessions', JSON.stringify(sessionsToSave));
            localStorage.setItem('happy-ai-theme-color', themeColor);
            localStorage.setItem('happy-ai-color-mode', colorMode);
            localStorage.setItem('happy-ai-use-memory', JSON.stringify(useMemory));
            if (currentSessionId) {
                localStorage.setItem('happy-ai-current-session-id', currentSessionId);
            }
        } catch (e) {
            console.error("Failed to save to localStorage", e);
        }
    }, [chatSessions, themeColor, colorMode, useMemory, currentSessionId]);

    // Update CSS variables and dark mode class
    useEffect(() => {
        const selectedTheme = THEME_COLORS.find(t => t.primary === themeColor) || THEME_COLORS[0];

        // Theme colors
        document.documentElement.style.setProperty('--theme-color', selectedTheme.primary);
        document.documentElement.style.setProperty('--theme-gradient', selectedTheme.gradient);
        
        // Dark/Light mode
        const root = window.document.documentElement;
        root.classList.remove(colorMode === 'dark' ? 'light' : 'dark');
        root.classList.add(colorMode);

    }, [themeColor, colorMode]);


    const updateSessionMessages = (sessionId: string, newMessages: Message[]) => {
        setChatSessions(prevSessions =>
            prevSessions.map(session =>
                session.id === sessionId ? { ...session, messages: newMessages } : session
            )
        );
    };

    const handleNewChat = useCallback(() => {
        setIsSwitchingChats(true); // Fade out current view
        setTimeout(() => {
            const newSessionId = `session_${Date.now()}`;
            const newSession: ChatSession = {
                id: newSessionId,
                title: 'New Chat',
                messages: [],
                createdAt: Date.now(),
                isNew: true
            };
            
            setChatSessions(prev => [newSession, ...prev.sort((a,b) => b.createdAt - a.createdAt)]);
            setCurrentSessionId(newSessionId);
            setMessages([]);
            setError(null);
            
            // Let the new view fade in
            setIsSwitchingChats(false);

            // Clean up the animation flag for the sidebar item after it has animated
            setTimeout(() => {
                setChatSessions(prev => prev.map(s => s.id === newSessionId ? { ...s, isNew: undefined } : s));
            }, 300);
        }, 300);
    }, []);

    const handleSelectChat = (sessionId: string) => {
        if (sessionId === currentSessionId) return;
        setIsSwitchingChats(true);
        setTimeout(() => {
            const session = chatSessions.find(s => s.id === sessionId);
            if (session) {
                setCurrentSessionId(sessionId);
                setMessages(session.messages);
                setError(null);
            }
            setIsSwitchingChats(false);
        }, 300);
    };

    const handleDeleteChat = (sessionId: string) => {
        const isDeletingActiveChat = currentSessionId === sessionId;
        setChatSessions(prev => prev.map(s => s.id === sessionId ? { ...s, isDeleting: true } : s));

        if (isDeletingActiveChat) setIsSwitchingChats(true);
        
        setTimeout(() => {
            setChatSessions(prevSessions => {
                const remainingSessions = prevSessions.filter(s => s.id !== sessionId);
                if (isDeletingActiveChat) {
                    const nextSession = remainingSessions.length > 0 ? remainingSessions.sort((a, b) => b.createdAt - a.createdAt)[0] : null;
                    setCurrentSessionId(nextSession ? nextSession.id : null);
                    setMessages(nextSession ? nextSession.messages : []);
                }
                return remainingSessions;
            });
            
            if (isDeletingActiveChat) setIsSwitchingChats(false);
        }, 300);
    };

    const handleSendMessage = useCallback(async (prompt: string, file?: UploadedFile) => {
        if (isLoading) return;

        let activeSessionId = currentSessionId;
        if (!activeSessionId) {
            const newId = `session_${Date.now()}`;
            const newSession: ChatSession = { id: newId, title: 'New Chat', messages: [], createdAt: Date.now() };
            setChatSessions(prev => [newSession, ...prev]);
            setMessages([]);
            setCurrentSessionId(newId);
            activeSessionId = newId;
        }

        setIsLoading(true);
        setError(null);

        const userMessage: Message = {
            id: Date.now().toString(),
            role: Role.USER,
            text: prompt,
            fileData: file?.base64,
            fileName: file?.name,
            fileType: file?.type,
        };

        const updatedMessages = [...messages, userMessage];
        setMessages(updatedMessages);

        if (messages.length === 0 && prompt) {
            generateChatTitle(prompt).then(title => {
                setChatSessions(prevSessions =>
                    prevSessions.map(session =>
                        session.id === activeSessionId ? { ...session, title } : session
                    )
                );
            });
        }
        
        try {
            if (prompt.startsWith(IMAGE_GEN_COMMAND)) {
                const imagePrompt = prompt.substring(IMAGE_GEN_COMMAND.length).trim();
                const aiMessageId = (Date.now() + 1).toString();
                const tempAiMessage: Message = { id: aiMessageId, role: Role.MODEL, text: 'Generating image...' };
                setMessages(prev => [...prev, tempAiMessage]);
                
                const imageUrl = await generateImage(imagePrompt);
                const finalAiMessage: Message = { 
                    ...tempAiMessage, 
                    text: `Image generated for: "${imagePrompt}"`, 
                    fileData: imageUrl,
                    fileName: `generated-image.png`,
                    fileType: 'image/png'
                };
                
                setMessages(prev => prev.map(m => m.id === aiMessageId ? finalAiMessage : m));
                updateSessionMessages(activeSessionId, [...updatedMessages, finalAiMessage]);

            } else if (prompt.startsWith(CODE_GEN_COMMAND)) {
                const codePrompt = prompt.substring(CODE_GEN_COMMAND.length).trim();
                const aiMessageId = (Date.now() + 1).toString();
                const tempAiMessage: Message = { id: aiMessageId, role: Role.MODEL, text: 'Generating code...', isCode: true };
                setMessages(prev => [...prev, tempAiMessage]);

                const codeResult = await generateCode(codePrompt);
                const finalAiMessage: Message = { ...tempAiMessage, text: codeResult, isCode: true };

                setMessages(prev => prev.map(m => m.id === aiMessageId ? finalAiMessage : m));
                updateSessionMessages(activeSessionId, [...updatedMessages, finalAiMessage]);

            } else {
                const aiMessageId = (Date.now() + 1).toString();
                const tempAiMessage: Message = { id: aiMessageId, role: Role.MODEL, text: '' };
                setMessages(prev => [...prev, tempAiMessage]);
                
                const pastSessions = useMemory
                    ? chatSessions
                        .filter(s => s.id !== activeSessionId)
                        .sort((a,b) => b.createdAt - a.createdAt)
                        .slice(0, 5) // Get the 5 most recent other sessions
                    : [];

                const stream = await streamChat(updatedMessages, currentModel, useGoogleSearch, pastSessions);
                
                let fullResponse = '';
                let finalResponseObject;
                let sources = [];

                for await (const chunk of stream) {
                    fullResponse += chunk.text;
                    setMessages(prev => prev.map(m => m.id === aiMessageId ? { ...m, text: fullResponse } : m));
                    finalResponseObject = chunk;
                }
                
                if (finalResponseObject) {
                    sources = getGroundingSources(finalResponseObject);
                }

                const finalAiMessage: Message = { id: aiMessageId, role: Role.MODEL, text: fullResponse, sources };
                updateSessionMessages(activeSessionId, [...updatedMessages, finalAiMessage]);
            }
        } catch (e: any) {
            const errorMessage = "An error occurred. Please try again.";
            setError(errorMessage);
            const errorAiMessage = { id: (Date.now() + 1).toString(), role: Role.MODEL, text: errorMessage };
            setMessages(prev => [...prev, errorAiMessage]);
            updateSessionMessages(activeSessionId, [...updatedMessages, errorAiMessage]);
            console.error(e);
        } finally {
            setIsLoading(false);
        }
    }, [isLoading, messages, currentModel, useGoogleSearch, currentSessionId, chatSessions, useMemory]);


    return (
        <div className="relative flex h-screen bg-transparent font-sans overflow-hidden">
             <Sidebar
                isOpen={isSidebarOpen}
                onClose={() => setIsSidebarOpen(false)}
                chatSessions={chatSessions}
                currentSessionId={currentSessionId}
                onSelectChat={handleSelectChat}
                onDeleteChat={handleDeleteChat}
                onNewChat={handleNewChat}
                themeColor={themeColor}
                setThemeColor={setThemeColor}
                colorMode={colorMode}
                setColorMode={setColorMode}
                useMemory={useMemory}
                setUseMemory={setUseMemory}
            />
            <div className="flex flex-col flex-1">
                <Header onNewChat={handleNewChat} onToggleSidebar={() => setIsSidebarOpen(true)} />
                <ChatWindow messages={messages} isLoading={isLoading} onNewChat={handleNewChat} isTransitioning={isSwitchingChats} />
                {error && (
                    <div className="py-2 px-4 bg-red-100 text-red-700 text-center text-sm">
                        {error}
                    </div>
                )}
                <ChatInput
                    onSendMessage={handleSendMessage}
                    isLoading={isLoading}
                    model={currentModel}
                    setModel={setCurrentModel}
                    useGoogleSearch={useGoogleSearch}
                    setUseGoogleSearch={setUseGoogleSearch}
                />
            </div>
        </div>
    );
};

export default App;