import React from 'react';
import { HappyAiLogo } from './icons';

interface WelcomeScreenProps {
  onNewChat: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onNewChat }) => {
    return (
        <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 dark:text-gray-400">
            <button 
              onClick={onNewChat} 
              className="group focus:outline-none logo-container"
              aria-label="Start new chat with Happy AI"
            >
              <HappyAiLogo className="w-24 h-24 text-gray-800 dark:text-gray-200 mb-4 group-hover:text-[--theme-color] transition-colors animate-bob animate-smile" />
            </button>
            <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-100">Hello, I'm Happy</h1>
            <p className="mt-2 text-lg">How can I assist you today?</p>
        </div>
    );
};

export default WelcomeScreen;