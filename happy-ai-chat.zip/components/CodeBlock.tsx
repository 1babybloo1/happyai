import React, { useState, useEffect } from 'react';
import { CopyIcon, CheckIcon } from './icons';

interface CodeBlockProps {
  code: string;
}

const CodeBlock: React.FC<CodeBlockProps> = ({ code }) => {
  const [isCopied, setIsCopied] = useState(false);

  const match = /^```(\w+)?\n([\s\S]+)\n```$/.exec(code.trim());

  const language = match ? match[1] || 'text' : null;
  const codeContent = match ? match[2].trim() : code;

  const handleCopy = () => {
    if (codeContent) {
      navigator.clipboard.writeText(codeContent);
      setIsCopied(true);
    }
  };

  useEffect(() => {
    if (isCopied) {
      const timer = setTimeout(() => {
        setIsCopied(false);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [isCopied]);

  if (!language) {
    // Fallback for loading text or non-code blocks
    return (
        <div className="bg-white dark:bg-gray-700 p-4">
             <div className="prose prose-sm max-w-none text-black dark:text-gray-200">
                {codeContent}
            </div>
        </div>
    );
  }

  return (
    <div className="bg-[#1e1e1e] text-gray-300 font-mono text-sm">
      <div className="flex justify-between items-center bg-gray-900/50 px-4 py-2">
        <span className="lowercase">{language}</span>
        <button
          onClick={handleCopy}
          className="flex items-center gap-1.5 text-xs hover:text-white transition-colors"
          aria-label={isCopied ? 'Copied' : 'Copy code'}
        >
          {isCopied ? (
            <>
              <CheckIcon className="w-4 h-4 text-green-400" />
              Copied!
            </>
          ) : (
            <>
              <CopyIcon className="w-4 h-4" />
              Copy
            </>
          )}
        </button>
      </div>
      <pre className="p-4 overflow-x-auto">
        <code>{codeContent}</code>
      </pre>
    </div>
  );
};

export default CodeBlock;
