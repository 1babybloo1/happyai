import React from 'react';
import { Message as MessageType, Role } from '../types';
import { HappyAiLogo, LoadingDots, FileTextIcon } from './icons';
import CodeBlock from './CodeBlock';

interface MessageProps {
  message: MessageType;
  isLoading: boolean;
}

const parseMarkdown = (text: string): React.ReactNode => {
    const elements: React.ReactNode[] = [];
    const lines = text.split('\n');
    let i = 0;

    const parseInline = (line: string): React.ReactNode => {
        return line.split(/(\*\*.*?\*\*)/g).map((part, index) => {
            if (part.startsWith('**') && part.endsWith('**')) {
                return <strong key={`strong-${index}`}>{part.slice(2, -2)}</strong>;
            }
            return part;
        });
    };

    while (i < lines.length) {
        const line = lines[i];

        // Headings
        if (line.startsWith('### ')) {
            elements.push(<h3 key={i} className="text-base font-semibold mt-3 mb-1">{parseInline(line.substring(4))}</h3>);
            i++;
            continue;
        }
        if (line.startsWith('## ')) {
            elements.push(<h2 key={i} className="text-lg font-semibold mt-4 mb-2">{parseInline(line.substring(3))}</h2>);
            i++;
            continue;
        }
        if (line.startsWith('# ')) {
            elements.push(<h1 key={i} className="text-xl font-semibold mt-4 mb-2">{parseInline(line.substring(2))}</h1>);
            i++;
            continue;
        }
        
        // Horizontal Rule
        if (line.trim() === '---') {
            elements.push(<hr key={i} className="my-3 border-gray-300 dark:border-gray-600" />);
            i++;
            continue;
        }

        // Unordered Lists
        const listRegex = /^\s*([*-])\s(.*)/;
        if (listRegex.test(line)) {
            const listItems: React.ReactNode[] = [];
            while (i < lines.length && listRegex.test(lines[i])) {
                const liLine = lines[i];
                const indentLevel = liLine.match(/^\s*/)?.[0].length || 0;
                const itemContent = liLine.replace(listRegex, '$2');
                
                listItems.push(
                    <li key={`li-${i}`} style={{ paddingLeft: `${indentLevel * 0.5}rem` }}>
                        {parseInline(itemContent)}
                    </li>
                );
                i++;
            }
            elements.push(<ul key={`ul-${i}`} className="list-disc list-outside space-y-1 my-2 pl-5">{listItems}</ul>);
            continue;
        }
        
        // Paragraphs
        if (line.trim() !== '') {
            elements.push(<p key={i} className="my-1 leading-relaxed">{parseInline(line)}</p>);
        }
        
        i++;
    }
    
    return elements;
};

const Message: React.FC<MessageProps> = ({ message, isLoading }) => {
  const isUser = message.role === Role.USER;

  const renderAttachment = () => {
    const { fileData, fileType, fileName } = message;
    if (!fileData || !fileType) return null;

    if (fileType.startsWith('image/')) {
        return <img src={fileData} alt={fileName || 'uploaded image'} className="max-w-xs rounded-lg shadow-md" />;
    }
    
    if (fileType.startsWith('video/')) {
        return <video src={fileData} controls className="max-w-xs rounded-lg shadow-md" />;
    }

    if (fileType.startsWith('audio/')) {
        return <audio src={fileData} controls className="w-full max-w-xs" />;
    }
    
    // Default file display for documents, 3D models etc.
    return (
        <div className="p-3 rounded-lg flex items-center gap-3 border border-current border-opacity-20">
            <FileTextIcon className="w-8 h-8 flex-shrink-0 opacity-80" />
            <div className="text-sm font-medium truncate">
                {fileName || 'Attached File'}
            </div>
        </div>
    );
  };

  const renderContent = () => {
    if (isLoading && message.text === '') {
      return <LoadingDots />;
    }

    if (message.isCode) {
        return <CodeBlock code={message.text} />;
    }
    
    return (
      <div className="flex flex-col gap-2">
        {renderAttachment()}
        {message.text && (
          <div className="max-w-none text-inherit">
              {parseMarkdown(message.text)}
          </div>
        )}
      </div>
    );
  };

  const renderSources = () => {
    if (!message.sources || message.sources.length === 0) return null;
    return (
      <div className="mt-4 border-t border-gray-400/20 pt-2">
        <h4 className="text-xs font-semibold text-gray-500 dark:text-gray-400 mb-2">Sources:</h4>
        <div className="flex flex-wrap gap-2">
          {message.sources.map((source, index) => (
            <a
              key={index}
              href={source.uri}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs bg-black/5 dark:bg-white/5 text-blue-600 dark:text-blue-400 hover:bg-black/10 dark:hover:bg-white/10 hover:text-blue-800 dark:hover:text-blue-300 px-2 py-1 rounded-md transition-colors"
            >
              {index + 1}. {source.title || new URL(source.uri).hostname}
            </a>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className={`flex items-end gap-3 my-2 ${isUser ? 'justify-end' : ''}`}>
      {!isUser && (
        <div className="w-8 h-8 flex-shrink-0 bg-gray-200 dark:bg-gray-600 rounded-full flex items-center justify-center text-gray-800 dark:text-gray-200 shadow-sm">
          <HappyAiLogo className="w-5 h-5" />
        </div>
      )}
      <div
        className={`${isUser ? 'max-w-xl' : 'max-w-3xl'} rounded-2xl shadow-md transition-all ${
          isUser
            ? 'text-white rounded-br-md'
            : 'bg-white/50 dark:bg-black/20 backdrop-blur-md text-black dark:text-gray-200 rounded-bl-md'
        } ${message.isCode ? 'p-0 bg-gray-800 dark:bg-black' : 'px-5 py-4'}`}
        style={isUser ? { background: `var(--theme-gradient, ${'var(--theme-color)'})` } : {}}
      >
        <div className={message.isCode ? 'rounded-[15px] overflow-hidden' : ''}>
          {renderContent()}
        </div>
        {!message.isCode && renderSources()}
      </div>
    </div>
  );
};

export default Message;