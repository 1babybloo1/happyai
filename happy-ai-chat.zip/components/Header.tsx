import React from 'react';
import { PlusIcon, MenuIcon } from './icons';

interface HeaderProps {
  onNewChat: () => void;
  onToggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ onNewChat, onToggleSidebar }) => {
  return (
    <header className="bg-white/30 dark:bg-black/20 backdrop-blur-lg p-4 flex justify-between items-center border-b border-white/20 dark:border-white/10 z-20 relative">
      <h1 className="text-xl font-bold text-gray-800 dark:text-gray-100">Happy AI</h1>
      <div className="flex items-center gap-2">
        <button
          onClick={onNewChat}
          className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          title="New Chat"
        >
          <PlusIcon className="w-6 h-6 text-gray-700 dark:text-gray-300" />
        </button>
        <button
          onClick={onToggleSidebar}
          className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors"
          title="Open Menu"
        >
          <MenuIcon className="w-6 h-6 text-gray-700 dark:text-gray-300" />
        </button>
      </div>
    </header>
  );
};

export default Header;